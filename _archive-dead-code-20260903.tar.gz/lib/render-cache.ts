export function buildKey(roomId: string, pieceId: string, lighting: string): string {
  return `${roomId}_${pieceId}_${lighting}`;
}

export function getCachedRender(): string | null {
  return null;
}
