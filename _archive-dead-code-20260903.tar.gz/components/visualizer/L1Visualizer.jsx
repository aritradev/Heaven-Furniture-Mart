export default function L1Visualizer() {
  return null;
}
