'use client';

import { motion } from 'framer-motion';
import Image from 'next/image';
import { images } from '@/lib/images';
import styles from './Collections.module.css';

const COLLECTIONS = [
  {
    key: 'living',
    title: 'Living Room',
    description: 'Sofas, coffee tables, TV units & consoles',
    image: images.classicSofa,
    span: 'large',
  },
  {
    key: 'bedroom',
    title: 'Bedroom',
    description: 'Beds, wardrobes, dressing tables & more',
    image: images.tealBed,
    span: 'medium',
  },
  {
    key: 'dining',
    title: 'Dining',
    description: 'Dining tables, chairs & display cabinets',
    image: images.diningTable,
    span: 'medium',
  },
  {
    key: 'office',
    title: 'Office & Chairs',
    description: 'Executive desks, bookshelves & workstations',
    image: images.executiveChair,
    span: 'large',
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.15,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] },
  },
};

export default function Collections({ onSelectCategory }) {
  const handleCardClick = (catKey) => {
    if (onSelectCategory) {
      onSelectCategory(catKey);
    }
    const catalogElem = document.getElementById('catalog');
    if (catalogElem) {
      catalogElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className={`section ${styles.collections}`} id="collections">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className={styles.header}
        >
          <span className="micro-label">Our Collections</span>
          <h2>Curated for Every Space</h2>
          <p className={styles.headerSub}>
            From the living room to the boardroom — select a category below to explore all listed items in our catalog.
          </p>
        </motion.div>

        <motion.div
          className={styles.grid}
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-60px' }}
        >
          {COLLECTIONS.map((item, index) => (
            <motion.div
              key={item.title}
              onClick={() => handleCardClick(item.key)}
              className={`${styles.card} ${styles[item.span]}`}
              variants={cardVariants}
              style={{ cursor: 'pointer' }}
            >
              <div className={styles.imageWrap}>
                <Image
                  src={item.image}
                  alt={`Heaven Furniture Mart — ${item.title} collection`}
                  fill
                  sizes="(max-width: 768px) 100vw, 50vw"
                  className={styles.image}
                  placeholder="blur"
                  priority={index < 2}
                />
              </div>
              <div className={styles.cardOverlay}>
                <div className={styles.cardContent}>
                  <span className={styles.cardNumber}>0{index + 1}</span>
                  <h3 className={styles.cardTitle}>{item.title}</h3>
                  <p className={styles.cardDesc}>{item.description}</p>
                  <span className={styles.cardCta}>
                    View {item.title} Items →
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
