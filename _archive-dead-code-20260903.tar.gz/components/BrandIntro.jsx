'use client';

import { motion } from 'framer-motion';
import styles from './BrandIntro.module.css';

export default function BrandIntro() {
  return (
    <section className={`section ${styles.brandIntro}`} id="about">
      <div className="container-narrow">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className={styles.content}
        >
          <div className="gold-divider" />
          <p className={styles.quote}>
            "At Heaven Furniture Mart, we believe furniture is more than just
            function; it is a reflection of lifestyle, taste, and comfort.
            Every piece we create is designed to bring lasting elegance into
            the homes of our clients."
          </p>
          <div className={styles.attribution}>
            <span className={styles.name}>Abul Kalam Bhuiyan</span>
            <span className={styles.role}>Managing Director & Founder</span>
          </div>
          <div className="gold-divider" />
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          className={styles.intro}
        >
          Founded in 2020, Heaven Furniture Mart has grown to become one of
          Chattogram's premier bespoke furniture studios. From our large
          showroom on Agrabad Access Road, we design and craft custom
          furniture — sofas, beds, dining sets, office pieces — built around
          what you actually want, not pulled off a shelf.
        </motion.p>
      </div>
    </section>
  );
}
