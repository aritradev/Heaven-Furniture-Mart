'use client';

import { motion } from 'framer-motion';
import Image from 'next/image';
import { images } from '@/lib/images';
import styles from './BespokeHighlight.module.css';

const FEATURES = [
  {
    icon: '✦',
    title: 'Free Design Consultation',
    desc: 'Share your vision — our team brings it to life, at no cost to you.',
  },
  {
    icon: '✦',
    title: 'Built to Your Exact Space',
    desc: 'Custom dimensions, materials, and finishes tailored to your home.',
  },
  {
    icon: '✦',
    title: 'Premium Materials',
    desc: 'Solid wood frames, high-resilience foam, and carefully sourced fabrics.',
  },
  {
    icon: '✦',
    title: 'In-House Craftsmanship',
    desc: 'Every piece made by our skilled artisans — never outsourced.',
  },
];

export default function BespokeHighlight() {
  return (
    <section className={`section ${styles.bespoke}`} id="bespoke">
      <div className={`container ${styles.inner}`}>
        {/* Image Side */}
        <motion.div
          className={styles.imageCol}
          initial={{ opacity: 0, x: -40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          <div className={styles.imageWrap}>
            <Image
              src={images.blueSofaPair}
              alt="Bespoke luxury sofa pair with gold accents — Heaven Furniture Mart"
              fill
              sizes="(max-width: 768px) 100vw, 50vw"
              className={styles.image}
              placeholder="blur"
            />
          </div>
          <div className={styles.imageAccent}>
            <Image
              src={images.glassShowcase}
              alt="Hand-carved wooden display showcase"
              fill
              sizes="200px"
              className={styles.image}
              placeholder="blur"
            />
          </div>
        </motion.div>

        {/* Text Side */}
        <motion.div
          className={styles.textCol}
          initial={{ opacity: 0, x: 40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.8, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
        >
          <span className="micro-label">The Heaven Difference</span>
          <h2 className={styles.title}>
            Your Vision.
            <br />
            <em>Our Craft.</em>
          </h2>
          <p className={styles.description}>
            Every piece of Heaven furniture starts with a conversation — your
            space, your style, your life. We don&apos;t sell from a catalog. We
            build around you. From concept to installation, experience
            furniture that&apos;s truly, uniquely yours.
          </p>

          <div className={styles.features}>
            {FEATURES.map((feature, i) => (
              <motion.div
                key={feature.title}
                className={styles.feature}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{
                  duration: 0.5,
                  delay: 0.3 + i * 0.1,
                  ease: [0.16, 1, 0.3, 1],
                }}
              >
                <span className={styles.featureIcon}>{feature.icon}</span>
                <div>
                  <h4 className={styles.featureTitle}>{feature.title}</h4>
                  <p className={styles.featureDesc}>{feature.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>

          <a
            href="https://wa.me/8801960481983?text=Hi%2C%20I'm%20interested%20in%20a%20bespoke%20furniture%20consultation"
            target="_blank"
            rel="noopener noreferrer"
            className="btn btn-primary"
            style={{ marginTop: 40 }}
          >
            Schedule Free Consultation
          </a>
        </motion.div>
      </div>
    </section>
  );
}
