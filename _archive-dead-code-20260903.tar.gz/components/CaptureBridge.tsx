export async function captureL1Snapshot(): Promise<string> {
  return '';
}
