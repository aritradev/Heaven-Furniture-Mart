export default function RenderResultOverlay() {
  return null;
}
