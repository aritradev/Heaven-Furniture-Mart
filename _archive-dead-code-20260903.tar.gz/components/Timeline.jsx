'use client';

import { motion } from 'framer-motion';
import styles from './Timeline.module.css';

const PROCESS_STEPS = [
  {
    number: '01',
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" />
      </svg>
    ),
    title: 'Free Consultation',
    desc: 'WhatsApp or visit our showroom. Tell us about your space, your style, and your budget. Zero commitment.',
    timeframe: '1–2 days',
  },
  {
    number: '02',
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 20h9" /><path d="M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z" />
      </svg>
    ),
    title: 'Design & Approval',
    desc: 'Our designers sketch your piece — dimensions, materials, finishes, and colour. You review and approve before a single cut is made.',
    timeframe: '2–4 days',
  },
  {
    number: '03',
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="3" width="18" height="18" rx="2" /><path d="M3 9h18" /><path d="M9 21V9" />
      </svg>
    ),
    title: 'Handcrafted',
    desc: 'Your furniture is built by our in-house artisans using solid Chittagong teak, premium velvets, and genuine leathers. Never outsourced.',
    timeframe: '2–4 weeks',
  },
  {
    number: '04',
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <rect x="1" y="3" width="15" height="13" /><polygon points="16,8 20,8 23,11 23,16 16,16 16,8" /><circle cx="5.5" cy="18.5" r="2.5" /><circle cx="18.5" cy="18.5" r="2.5" />
      </svg>
    ),
    title: 'Delivered & Installed',
    desc: "White-glove delivery to your door. Professional assembly included. We don't leave until everything is perfect.",
    timeframe: 'Same day',
  },
];

const containerVariants = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.12 } },
};

const stepVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.65, ease: [0.16, 1, 0.3, 1] } },
};

export default function Timeline() {
  return (
    <section className={`section ${styles.timeline}`} id="timeline">
      <div className="container">

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className={styles.header}
        >
          <span className="micro-label">The Process</span>
          <h2>From Vision to Reality</h2>
          <p className={styles.headerSub}>
            Four simple steps — designed to make ordering bespoke furniture completely effortless.
          </p>
        </motion.div>

        {/* Process Steps */}
        <motion.div
          className={styles.processGrid}
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-40px' }}
        >
          {PROCESS_STEPS.map((step, i) => (
            <motion.div key={step.number} className={styles.processStep} variants={stepVariants}>
              <div className={styles.stepNumberWrap}>
                <span className={styles.stepNumber}>{step.number}</span>
              </div>
              <div className={styles.stepIconWrap}>{step.icon}</div>
              <h4 className={styles.stepTitle}>{step.title}</h4>
              <p className={styles.stepDesc}>{step.desc}</p>
              <div className={styles.stepTimeframe}>
                <span>⏱ Est. {step.timeframe}</span>
              </div>
              {i < PROCESS_STEPS.length - 1 && (
                <div className={styles.stepArrow} aria-hidden="true">→</div>
              )}
            </motion.div>
          ))}
        </motion.div>

        {/* Process CTA */}
        <motion.div
          className={styles.processCta}
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
        >
          <p className={styles.processCtaText}>Questions? We answer within minutes.</p>
          <a
            href="https://wa.me/8801960481983?text=Hi%2C%20I%20have%20a%20question%20about%20ordering%20custom%20furniture%20from%20Heaven%20Furniture%20Mart"
            target="_blank"
            rel="noopener noreferrer"
            className="btn btn-whatsapp"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
            </svg>
            Ask Us on WhatsApp
          </a>
        </motion.div>

      </div>
    </section>
  );
}
