'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Image from 'next/image';
import { images } from '@/lib/images';
import styles from './SeeInYourRoom.module.css';

const ROOM_STYLES = [
  {
    key: 'classic',
    label: 'Classic Elegance',
    headline: 'Timeless Grandeur',
    desc: 'Hand-carved teak frames, cream velvet upholstery, and gold-leaf accents create a living room your guests will never forget.',
    image: images.classicSofa,
    accent: '#B08D57',
  },
  {
    key: 'modern',
    label: 'Modern Luxury',
    headline: 'Clean. Bold. Yours.',
    desc: 'Minimalist lines, premium leathers, and modular layouts designed for the contemporary Bangladeshi home.',
    image: images.modularSofa,
    accent: '#6B8E9F',
  },
  {
    key: 'royal',
    label: 'Royal Statement',
    headline: 'Live Like Royalty',
    desc: 'Deep blue velvet, marble dining surfaces, and opulent headboards — for those who refuse to compromise.',
    image: images.navyBed,
    accent: '#4A3F7A',
  },
];

export default function SeeInYourRoom() {
  const [active, setActive] = useState('classic');
  const current = ROOM_STYLES.find((s) => s.key === active);

  return (
    <section className={`section ${styles.seeInYourRoom}`} id="interior-styling" aria-label="Interior Styling Preview">
      <div className="container">
        {/* Header */}
        <motion.div
          className={styles.header}
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
        >
          <span className="micro-label">Interior Styling</span>
          <h2 className={styles.headerTitle}>
            Imagine It
            <br />
            <em>In Your Room</em>
          </h2>
          <p className={styles.headerSub}>
            Not sure which style suits your space? Our design team creates a free room preview tailored to your home&apos;s dimensions, colour palette, and personality.
          </p>
        </motion.div>

        {/* Style Selector Tabs */}
        <motion.div
          className={styles.tabs}
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
        >
          {ROOM_STYLES.map((s) => (
            <button
              key={s.key}
              className={`${styles.tab} ${active === s.key ? styles.tabActive : ''}`}
              onClick={() => setActive(s.key)}
            >
              {s.label}
            </button>
          ))}
        </motion.div>

        {/* Content Area */}
        <div className={styles.showcase}>
          {/* Image */}
          <div className={styles.imageCol}>
            <AnimatePresence mode="wait">
              <motion.div
                key={active}
                className={styles.imageWrap}
                initial={{ opacity: 0, scale: 1.03 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
              >
                <Image
                  src={current.image}
                  alt={`${current.headline} — Heaven Furniture Mart interior style`}
                  fill
                  sizes="(max-width: 768px) 100vw, 55vw"
                  className={styles.roomImage}
                />
                {/* Style overlay badge */}
                <div className={styles.styleBadge}>
                  <span>{current.label}</span>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Details */}
          <AnimatePresence mode="wait">
            <motion.div
              key={`text-${active}`}
              className={styles.detailsCol}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            >
              <div
                className={styles.accentLine}
                style={{ background: current.accent }}
              />
              <h3 className={styles.styleHeadline}>{current.headline}</h3>
              <p className={styles.styleDesc}>{current.desc}</p>

              <ul className={styles.featureList}>
                <li>✦ Free room layout preview</li>
                <li>✦ Tailored to your space dimensions</li>
                <li>✦ Fabric & colour consultation included</li>
                <li>✦ No obligation — just inspiration</li>
              </ul>

              <a
                href={`https://wa.me/8801960481983?text=Hi%2C%20I'm%20interested%20in%20the%20${encodeURIComponent(current.label)}%20interior%20styling%20service.%20Can%20I%20get%20a%20free%20room%20preview%3F`}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-primary"
              >
                Request Free Room Preview
              </a>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
