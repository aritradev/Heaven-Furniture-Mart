export default function UploadSlots() {
  return null;
}
