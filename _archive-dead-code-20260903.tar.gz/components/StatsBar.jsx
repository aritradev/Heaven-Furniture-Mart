'use client';

import { useEffect, useRef, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import styles from './StatsBar.module.css';

const STATS = [
  { value: 500, suffix: '+', label: 'Happy Homeowners' },
  { value: 10, suffix: '+', label: 'Years of Craftsmanship' },
  { value: 200, suffix: '+', label: 'Bespoke Projects' },
  { value: 1, suffix: '', label: 'Showroom in Chattogram' },
];

function CountUp({ target, suffix, duration = 1800 }) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-60px' });
  const started = useRef(false);

  useEffect(() => {
    if (!inView || started.current) return;
    started.current = true;
    const start = performance.now();

    const tick = (now) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      // Ease-out cubic
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.round(eased * target));
      if (progress < 1) requestAnimationFrame(tick);
    };

    requestAnimationFrame(tick);
  }, [inView, target, duration]);

  return (
    <span ref={ref}>
      {count}{suffix}
    </span>
  );
}

export default function StatsBar() {
  const sectionRef = useRef(null);
  const inView = useInView(sectionRef, { once: true, margin: '-40px' });

  return (
    <section className={styles.statsBar} ref={sectionRef} aria-label="Heaven Furniture Mart Statistics">
      <div className={styles.inner}>
        {STATS.map((stat, i) => (
          <motion.div
            key={stat.label}
            className={styles.stat}
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
          >
            <span className={styles.number}>
              {inView ? (
                <CountUp target={stat.value} suffix={stat.suffix} />
              ) : (
                `0${stat.suffix}`
              )}
            </span>
            <span className={styles.label}>{stat.label}</span>
            {i < STATS.length - 1 && <div className={styles.divider} aria-hidden="true" />}
          </motion.div>
        ))}
      </div>
    </section>
  );
}
